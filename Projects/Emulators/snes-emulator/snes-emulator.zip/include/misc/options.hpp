#pragma once

constexpr bool SST_TEST = false;
constexpr bool PRINT_CARTRIDGE = false;
constexpr bool HALF_CYCLES = false;
constexpr bool SEE_TOTAL_PASS_ONLY = false;

constexpr bool SINGLE_TEST = false;
